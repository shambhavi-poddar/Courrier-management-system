<!-- copyright and contactUs fixed footer -->

<!DOCTYPE html>
<html>
<head>
<style>
.footer {
    position: fixed;
    width: 100%;
    text-align: center;
    
    bottom: 0;
    background-color: #2ab7ca;
    color: white;
}
</style>
</head>
<body>
<footer class="footer">

  <p style="margin-top: 4px;margin-bottom:-10px">Copyright © 2020 Designed By Himanshu Soni and Love Raj</p><br>
  <a href="mailto:premkumar1215225@gmail.com" style="color:brown">ContactUs</a>

</footer>

</body>
</html>
